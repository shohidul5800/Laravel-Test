<!DOCTYPE html>
<html lang="en">
<head>
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('images/ajax-loader.gif')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

</head>
<body>

<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer class="footer-warp">

    <div class="container-fluid bg-dark">
        <div class="container text-center">
            <div class="row pt-5 pb-5">
                <div class="col-lg-12">
                    <h3 class="text-white">Footer</h3>
                </div>
            </div>
        </div>
    </div>

</footer>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f08968cedc2a851"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\data\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>