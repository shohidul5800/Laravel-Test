<?php $__env->startSection('title'); ?>
    <?php echo e(__('Home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="content">

        <div class="container-fluid bg-light mb-3">
            <div class="container">
                <div class="row">

                    <div class="col-lg-8">
                        <h4>Section 1</h4>
                        <hr>
                        <div class="row">

                            <?php $__currentLoopData = $videoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6">
                                    <div class="container">
                                        <img class="img-thumbnail" src="<?php echo e(asset('images/video/photo')); ?>/<?php echo e($video->photo); ?>" alt="Snow" style="width:100%; height: 300px">
                                        <a href="<?php echo e(route('video.view', $video->id)); ?>" class="btn btn-dark btn-sm"><span class="icon-play"></span></a>

                                        <div class="text pt-4">
                                            <a href="<?php echo e(route('video.view', $video->id)); ?>"><?php echo e(str_limit($video->title, 50)); ?></a>
                                            <p><?php echo e(str_limit($video->short_description, 80)); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-6">
                                <div class="row">
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6">
                                            <div class="container">
                                                <img class="img-thumbnail" src="<?php echo e(asset('images/video/photo')); ?>/<?php echo e($video->photo); ?>" alt="Snow" style="width:100%; height: 120px;">
                                                <a href="<?php echo e(route('video.view', $video->id)); ?>" class="btn2 btn-dark btn-sm"><span class="icon-play"></span></a>

                                                <div class="text pt-2">
                                                    <a href="<?php echo e(route('video.view', $video->id)); ?>"><?php echo e(str_limit($video->title, 18)); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 border-left">
                        <h4>Section 2</h4>
                        <hr>
                        <div class="row">
                        <?php $__currentLoopData = $postss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-12">
                                <div class="container">
                                    <img class="img-thumbnail" src="<?php echo e(asset('images/post/photo')); ?>/<?php echo e($post->photo); ?>" alt="Snow" style="width:100%;">

                                    <div class="text pt-4">
                                        <a href="<?php echo e(route('post.view', $post->id)); ?>"><?php echo e(str_limit($post->title, 50)); ?></a>
                                        <p><?php echo e(str_limit($post->short_description, 80)); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-12">
                                <div class="row">
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6">
                                        <div class="container">
                                            <img class="img-thumbnail" src="<?php echo e(asset('images/post/photo')); ?>/<?php echo e($post->photo); ?>" alt="Snow" style="width:100%; height: 120px;">

                                            <div class="text pt-2">
                                                <a href="<?php echo e(route('post.view', $post->id)); ?>"><?php echo e(str_limit($post->title, 50)); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div>
                        </div>
                    </div>

                </div><!--    End of  row -->
            </div><!--    End of Container -->
        </div><!--    End of Container-fluid -->

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\data\resources\views/welcome.blade.php ENDPATH**/ ?>