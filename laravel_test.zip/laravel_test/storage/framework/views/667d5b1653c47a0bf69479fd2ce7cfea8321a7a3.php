<header class="header mb-5">

    <div class="container-fluid bg-light fixed-top">
        <div class="container text-center">
            <div class="row pt-1 pb-1">
                <div class="col-lg-6 text-lg-left">
                    <a href="#" class="top-menu"><span class="icon-envelope"></span> shohidulislamsaju@gmail.com</a>
                    <a href="#" class="top-menu"><span class="icon-phone"></span> +8801779 238790</a>
                </div>

                <div class="col-lg-6 text-lg-right">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="top-menu"><span class="icon-signin"></span> Login</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="top-menu"><span class="icon-adjust"></span> Register</a>
                    <?php endif; ?>
                <?php else: ?>
                        <a class="top-menu" href="<?php echo e(route('home')); ?>" >  <span class="icon-user"></span> <?php echo e(Auth::user()->name); ?></a>
                        <a class="top-menu" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <span class="icon-signout"></span><?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid bg-white space">
        <div class="container text-center">
            <div class="row pt-1 pb-1">
                <div class="col-lg-6 text-lg-left">
                    <div class="site-logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <h1>Logo</h1>
                        </a>
                    </div>
                </div>

                <div class="col-lg-6 text-lg-right mt-3">
                    <a href="#" class="social-menu"><span class="icon-facebook-sign"></span></a>
                    <a href="#" class="social-menu"><span class="icon-linkedin-sign"></span></a>
                    <a href="#" class="social-menu"><span class="icon-twitter-sign"></span></a>
                    <a href="#" class="social-menu"><span class="icon-youtube-sign"></span></a>
                    <a href="#" class="social-menu"><span class="icon-instagram"></span></a>
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#Navbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="container">
            <div class="collapse navbar-collapse" id="Navbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Post</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Video</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Data
                        </a>
                        <div class="dropdown-menu bg-dark mt-2">
                            <a class="dropdown-item" href="#">Data 1</a>
                            <a class="dropdown-item" href="#">Data 2</a>
                            <a class="dropdown-item" href="#">Data 3</a>
                        </div>
                    </li>
                </ul>
            </div>

            <form class="form-inline" action="#" method="post">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text search"><span class="icon-search"></span> </span>
                    </div>
                    <input type="text" name="search" class="form-control" placeholder="Search Keyword..">
                </div>
            </form>
        </div>
    </nav>

</header>
<?php /**PATH C:\xampp\htdocs\data\resources\views/frontend/header.blade.php ENDPATH**/ ?>