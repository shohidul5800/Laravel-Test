<?php if(!$post == ''): ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(__('Post :')); ?> <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid bg-light mb-5">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 offset-2">
                    <h3><?php echo e($post->title); ?></h3>

                    <img src="<?php echo e(asset('images/post/photo')); ?>/<?php echo e($post->photo); ?>" class="img-thumbnail" style="width: 100%; height: 300px;">

                    <p class="pt-4 pb-4"><?php echo e($post->short_description); ?></p><br>
                    <p class="pt-2 pb2 pl-2 pr-2 border"><?php echo e($post->long_description); ?></p>

                    <br>
                    <br>
                    <br>
                    <h5>Share..</h5>

                    <div class="addthis_inline_share_toolbox_i3cc"></div>
                </div>

            </div><!--    End of  row -->
        </div><!--    End of Container -->
    </div><!--    End of Container-fluid -->

<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\data\resources\views/frontend/post_view.blade.php ENDPATH**/ ?>