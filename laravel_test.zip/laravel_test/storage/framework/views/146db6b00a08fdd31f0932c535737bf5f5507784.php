<?php $__env->startSection('title'); ?>
    <?php echo e(__('Section 1')); ?>

<?php $__env->stopSection(); ?>
<?php if(auth()->guard()->check()): ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Section 1 / Video</div>

                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Title</th>
                                <th>Short_ Description</th>
                                <th>Publish</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset('images/video/photo')); ?>/<?php echo e($video->photo); ?>" class="img-thumbnail" style="width: 90px; height: 90px">
                                    </td>
                                    <td><?php echo e($video->title); ?></td>
                                    <td><?php echo e($video->short_description); ?></td>
                                    <td><?php echo e($video->status); ?></td>
                                    <td width="150px">
                                        <a href="<?php echo e(route('video.delete', $video->id)); ?>" class="btn btn-sm btn-danger"> <?php echo e(__('Delete')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Add Video</div>

                    <div class="card-body">
                        <form action="<?php echo e(route('video.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Title :</label>
                                <input type="text" name="title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Keyword...">
                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Short Description :</label>
                                <textarea type="text" rows="3" name="short_description" class="form-control <?php if ($errors->has('short_description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('short_description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Keyword..."></textarea>
                                <?php if ($errors->has('short_description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('short_description'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Long Description :</label>
                                <textarea rows="5" type="text" name="long_description" class="form-control <?php if ($errors->has('long_description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('long_description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Keyword..."></textarea>
                                <?php if ($errors->has('long_description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('long_description'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Video Youtube Embed Link :</label>
                                <input type="url" name="short_link" class="form-control <?php if ($errors->has('short_link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('short_link'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Keyword...">
                                <?php if ($errors->has('short_link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('short_link'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Photo :</label>
                                <input type="file" name="photo" class="form-control <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Keyword...">
                                <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group">
                                <label>The Video is Publish :</label>
                                <input type="radio" name="status" value="yes" class="" required> Yes
                                <input type="radio" name="status" value="no" class="" required> No

                            </div>

                            <br>
                            <button class="btn btn-sm btn-dark" type="submit"><?php echo e(__('SUBMIT')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\data\resources\views/backend/video.blade.php ENDPATH**/ ?>