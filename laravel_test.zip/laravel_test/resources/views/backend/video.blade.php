@extends('layouts.app')

@section('title')
    {{__('Section 1')}}
@endsection
@auth()
@section('content')
    <div class="container">
        @if(Session::has('message'))
            <div class="alert alert-success">
                {{Session::get('message')}}
            </div>
        @endif
        <div class="row justify-content-center">

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Section 1 / Video</div>

                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Title</th>
                                <th>Short_ Description</th>
                                <th>Publish</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($videos as $video)
                                <tr>
                                    <td>
                                        <img src="{{ asset('images/video/photo') }}/{{ $video->photo }}" class="img-thumbnail" style="width: 90px; height: 90px">
                                    </td>
                                    <td>{{ $video->title }}</td>
                                    <td>{{ $video->short_description }}</td>
                                    <td>{{ $video->status }}</td>
                                    <td width="150px">
                                        <a href="{{ route('video.delete', $video->id) }}" class="btn btn-sm btn-danger"> {{__('Delete')}}</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Add Video</div>

                    <div class="card-body">
                        <form action="{{ route('video.store') }}" method="post" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group">
                                <label>Title :</label>
                                <input type="text" name="title" class="form-control @error('title') is-invalid @enderror" placeholder="Keyword...">
                                @error('title')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>Short Description :</label>
                                <textarea type="text" rows="3" name="short_description" class="form-control @error('short_description') is-invalid @enderror" placeholder="Keyword..."></textarea>
                                @error('short_description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>Long Description :</label>
                                <textarea rows="5" type="text" name="long_description" class="form-control @error('long_description') is-invalid @enderror" placeholder="Keyword..."></textarea>
                                @error('long_description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>Video Youtube Embed Link :</label>
                                <input type="url" name="short_link" class="form-control @error('short_link') is-invalid @enderror" placeholder="Keyword...">
                                @error('short_link')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>Photo :</label>
                                <input type="file" name="photo" class="form-control @error('photo') is-invalid @enderror" placeholder="Keyword...">
                                @error('photo')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>The Video is Publish :</label>
                                <input type="radio" name="status" value="yes" class="" required> Yes
                                <input type="radio" name="status" value="no" class="" required> No

                            </div>

                            <br>
                            <button class="btn btn-sm btn-dark" type="submit">{{__('SUBMIT')}}</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@endauth
