@extends('layouts.frontend')

@section('title')
    {{__('Home')}}
@endsection

@section('content')


    <div class="content">

        <div class="container-fluid bg-light mb-3">
            <div class="container">
                <div class="row">

                    <div class="col-lg-8">
                        <h4>Section 1</h4>
                        <hr>
                        <div class="row">

                            @foreach($videoss as $video)
                                <div class="col-lg-6">
                                    <div class="container">
                                        <img class="img-thumbnail" src="{{ asset('images/video/photo') }}/{{ $video->photo }}" alt="Snow" style="width:100%; height: 300px">
                                        <a href="{{ route('video.view', $video->id) }}" class="btn btn-dark btn-sm"><span class="icon-play"></span></a>

                                        <div class="text pt-4">
                                            <a href="{{ route('video.view', $video->id) }}">{{ str_limit($video->title, 50) }}</a>
                                            <p>{{ str_limit($video->short_description, 80) }}</p>
                                        </div>
                                    </div>
                                </div>
                            @endforeach

                            <div class="col-lg-6">
                                <div class="row">
                                    @foreach($videos as $video)
                                        <div class="col-lg-6">
                                            <div class="container">
                                                <img class="img-thumbnail" src="{{ asset('images/video/photo') }}/{{ $video->photo }}" alt="Snow" style="width:100%; height: 120px;">
                                                <a href="{{ route('video.view', $video->id) }}" class="btn2 btn-dark btn-sm"><span class="icon-play"></span></a>

                                                <div class="text pt-2">
                                                    <a href="{{ route('video.view', $video->id) }}">{{ str_limit($video->title, 18) }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 border-left">
                        <h4>Section 2</h4>
                        <hr>
                        <div class="row">
                        @foreach($postss as $post)
                            <div class="col-lg-12">
                                <div class="container">
                                    <img class="img-thumbnail" src="{{ asset('images/post/photo') }}/{{ $post->photo }}" alt="Snow" style="width:100%;">

                                    <div class="text pt-4">
                                        <a href="{{ route('post.view', $post->id) }}">{{ str_limit($post->title, 50) }}</a>
                                        <p>{{ str_limit($post->short_description, 80) }}</p>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                            <div class="col-lg-12">
                                <div class="row">
                                @foreach($posts as $post)
                                    <div class="col-lg-6">
                                        <div class="container">
                                            <img class="img-thumbnail" src="{{ asset('images/post/photo') }}/{{ $post->photo }}" alt="Snow" style="width:100%; height: 120px;">

                                            <div class="text pt-2">
                                                <a href="{{ route('post.view', $post->id) }}">{{ str_limit($post->title, 50) }}</a>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                </div>

                            </div>
                        </div>
                    </div>

                </div><!--    End of  row -->
            </div><!--    End of Container -->
        </div><!--    End of Container-fluid -->

    </div>

@endsection

