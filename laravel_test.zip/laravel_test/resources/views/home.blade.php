@extends('layouts.app')

@section('title')
    {{__('Dashboard')}}
@endsection
@auth()
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>Role</th>
                                <td>:</td>
                                <td>{{ auth()->user()->role }}</td>
                            </tr>
                            <tr>
                                <th>Admin Name</th>
                                <td>:</td>
                                <td>{{ auth()->user()->name }}</td>
                            </tr>
                            <tr>
                                <th>Admin Email</th>
                                <td>:</td>
                                <td>{{ auth()->user()->email }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@endauth
