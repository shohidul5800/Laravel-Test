@extends('layouts.frontend')
@if(!$video == '')
@section('title')
    {{__('Video :')}} {{ $video->title }}
@endsection

@section('content')

    <div class="container-fluid bg-light mb-5">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 offset-2">
                    <h3>{{ $video->title }}</h3>

                    <img src="{{ asset('images/video/photo') }}/{{ $video->photo }}" class="img-thumbnail" style="width: 100%; height: 300px;">

                    <p class="pt-4 pb-4">{{ $video->short_description }}</p><br>
                    <iframe width="100%" height="345" src="{{ $video->short_link }}"></iframe>
                    <p class="pt-2 pb2 pl-2 pr-2 border">{{ $video->long_description }}</p>

                    <br>
                    <br>
                    <br>
                    <h5>Share..</h5>

                    <div class="addthis_inline_share_toolbox_i3cc"></div>
                </div>

            </div><!--    End of  row -->
        </div><!--    End of Container -->
    </div><!--    End of Container-fluid -->

@endsection
@endif